
 //let numeroSecreto=6
 //let numeroUsuario = prompt("Me indicas un número por favor");

 ////console.log(numeroUsuario);

 //if(numeroUsuario==numeroSecreto)
// {
//  alert('Acertaste el númeno');
 //}
 
//else{
   // alert('Lo siento no acertaste!!')
//}



////EJERECICIOS ://////


//1/Muestra una alerta con el mensaje "¡Bienvenida y bievenido a nuestro sitio web!".//

//alert("¡Bienvenida y/o  Bievenido a Nuestro Sitio Web!");


//2/Declara una variable llamada nombre y asígnale el valor "Luna".//
 //let nombre = "luna";

 
//3/Crea una variable llamada edady asígnale el valor 25.

//let edady=25;


//4/Establece una variable numeroDeVentas y asígnale el valor 50.

///let numeroDeVentas=50;


//5/Establece una variable saldoDisponible y asígnale el valor 1000.
///let saldoDisponible=1000;


//6///Muestra una alerta con el texto "¡Error! Completa todos los campos".
 //alert("¡Error! Completa todos los campos.");



 //7/Declara una variable llamada mensajeDeError y asígnale el valor "¡Error! 
 //Completa todos los campos". Ahora muestra una alerta con el valor de la variable mensajeDeError .

// let mensajeDeError="¡Error! Completa todos los campos";
//alert('¡Error! Completa todos los campos');




 //8//Utiliza un prompt para preguntar el nombre del usuario y almacénalo en la variable nombre ./


 //let nombreUsuario= prompt ("Favor colocar su Nombre!");
 //let nombre=nombreUsuario;
 //if (nombre==nombreUsuario){

   // alert('Bienvenido/a! '+nombre);
 //}


 ///9/Pide al usuario que ingrese su edad usando un prompt y almacénala en la variable edad.//

  //let edadDeIngreso = prompt ("Ingrese su Edad por favor!");
  //let edad=edadDeIngreso;


  ///10//Ahora, si la edad es mayor o igual a 18, muestra una alerta con el mensaje "¡Puedes obtener tu licencia de conducir!".

  //let edadDeIngreso = prompt ("Ingrese su Edad por favor!");
  //let edad=edadDeIngreso;

  //if(edad>=18 ){
    //alert('¡Puedes obtener tu licencia de conducir!');
  //}
  //else
  //{
  //alert('favor de esperar hasta ser mayor de edad!')
 // }

 


 /* Segunda parte de los ejercicios */


 /*
 1)Pregunta al usuario qué día de la semana es. Si la respuesta 
 es "Sábado" o "Domingo", muestra "¡Buen fin de semana!". De lo contrario, muestra "¡Buena semana!".
 */

 //let preguntaUsuario =prompt ("Qué día de la semana es:");


 //if (preguntaUsuario=='Sábado' || preguntaUsuario== 'Domingo') {
 //console.log("¡Buen fin de Semana!");
 //}

 //else  {
  //console.log('Buen día de semana');
 //}



 /*
 2)Verifica si un número ingresado por el usuario es positivo o negativo. Muestra una alerta informativa.
 */
//let numeroDelUsuraio= prompt("Digite un Número");

//if(numeroDelUsuraio>0){
  //console.log('Número Positivo');
//}

//else{
 // console.log('Número Negativo');
//}


/*3)
Crea un sistema de puntuación para un juego. Si la puntuación es mayor o igual a 100, muestra
 "¡Felicidades, has ganado!". En caso contrario, muestra "Intenta nuevamente para ganar.".
*/

//let puntuacion =prompt('Ingrese su puntuación');

//if (puntuacion>=100)
//{
 // alert('¡Felicidades, has ganado!');
//}
//else {
  //console.log('Intenta nuevamente para ganar');
//}



/*4)Crea un mensaje que informe al usuario sobre el saldo de su cuenta, utilizando un template string para incluir el valor del saldo.
*/

//let saldoUsraio = prompt('Ingrese su Saldo');
//alert(`Su Saldo es de : ${saldoUsraio}`);


/*5)Pide al usuario que ingrese su nombre mediante un prompt. Luego, muestra una alerta de bienvenida usando ese nombre.
*/

//let nombreUsarioIngreso = prompt('Ingrese su nombre, por favor!');
//alert('Bienvenido/a!.  ' +nombreUsarioIngreso);


/*Bloque de ejercicios III*/

/*1)Crea un contador que comience en 1 y vaya hasta 10
 usando un bucle 'while'. Muestra cada número.
*/

///let contador =1;

//while (contador<= 10){

 //console.log(contador);
 
 // contador++;
//}

/*2)
Crea un contador que comience en 10 y vaya hasta 0 usando un bucle 'while'. Muestra cada número.
*/

//let contador =10;

//while (contador>0){

 //console.log(contador);
 
  //contador--;
//}
 //alert(`la suma de los diez números es:  ${contador}`)


/*3)
Crea un programa de cuenta progresiva. Pide un número y cuenta desde 0 hasta ese número utilizando un bucle 'while' en la consola del navegador.
*/
//let numeroPedido = parseInt(prompt("Ingresa un número:"));

   // console.log("La cuenta progresiva es:");

    //let contador = 0;

    //while (contador <= numeroPedido) {
    //    alert(contador);
       // contador++;
    //}


///////////////////////////////////////////////////////////EJERCICIOS IV/////////////////////////////////////////////////////

  /*1)
  Crea un programa que utilice console.log para mostrar un mensaje de bienvenida.
  */

 //console.log('Bienvenidos/a!!');

/*2)
Crea una variable llamada "nombre" y 
asígnale tu nombre. Luego, utiliza console.log para mostrar el mensaje "
¡Hola, [tu nombre]!" en la consola del navegador.
*/

//let nombre= 'Altagracia';
//console.log(`¡Hola!. ${nombre}`);


/*3)Crea una variable llamada "nombre" y asígnale tu nombre. Luego, utiliza alert para mostrar el mensaje "¡Hola, [tu nombre]!".
*/
//let nombres= 'Altagracia';
//alert(`¡Hola!.  ${nombres}!`);


/*4)Utiliza prompt y haz la siguiente pregunta: ¿Cuál es el lenguaje 
de programación que más te gusta?. Luego, almacena la respuesta en 
una variable y muestra la respuesta en la consola del navegador.
*/

//let pregunta =prompt('Cuál es el lenguaje de programación que más te gusta?.');
 //let respuesta=pregunta;
 //console.log(respuesta);


 /*5)Crea una variable llamada "valor1" y otra llamada "valor2", asignándoles valores numéricos de tu elección. Luego,
  realiza la suma de estos dos valores y almacena el resultado en una tercera variable llamada "resultado". 
 Utiliza console.log para mostrar el mensaje "La suma de [valor1] y [valor2] es igual a [resultado]." en la consola.
 */
//let valor1=9;
//let valor2=8;
//let resultado=valor1+valor2;
//console.log(`La suma de  ${valor1} y ${valor2} es igual a:  ${resultado}`);


/*6)
Crea una variable llamada "valor1" y otra llamada "valor2", asignándoles valores numéricos de
 tu elección. Luego, realiza la resta de estos dos valores y almacena el resultado en una tercera variable llamada "resultado". 
Utiliza console.log para mostrar el mensaje "La diferencia entre [valor1] y [valor2] es igual a [resultado]." en la consola.
*/

//let valor1=10;
//let valor2=6;
//let resultado=valor1-valor2;
//console.log(`La diferencia entre  ${valor1} y ${valor2} es igual a:  ${resultado}`);

/*7)
Pide al usuario que ingrese su edad con prompt. Con base en la edad ingresada, 
utiliza un if para verificar si la persona es mayor o menor de edad y muestra un mensaje apropiado en la consola.
*/  

//let edadIngre =prompt("Ingrese su Edad:");
//let edad=edadIngre;

//if(edad >= 18){
//console.log('Usted es Mayor de Edad.!');
//}

//else 
//{
// console.log('Usted es Menor de Edad.'); 
//}


/*8)Crea una variable "numero" y solicita un valor con prompt. 
Luego, verifica si es positivo, negativo o cero utilizando un if-else y muestra el mensaje correspondiente.
*/

//let numeroSolicitado= prompt("Ingrese un Número");
//numero =numeroSolicitado;

//if(numero>0)
//{
//console.log('El Número es Positivo!');
//}
//else
//{
 // console.log('El Número es Negativo!');
//}

/*9)
Utiliza un bucle while para mostrar los números del 1 al 10 en la consola
*/
//numero =1;

//while(numero<=10)
//{
//console.log(numero)
//numero++
//}

/*10)
Crea una variable "nota" y asígnale un valor numérico. 
Utiliza un if-else para determinar si la nota es mayor o igual a 7 y muestra "Aprobado" o "Reprobado" en la consola.
*/
//let nota =6;
//if(nota>=7)
//{
//console.log('Aprobado!');
//}
//else
//{
 // console.log('Reprobado!');
//}

/*11)Utiliza Math.random para generar cualquier número aleatorio y muestra ese número en la consola.
*/

//let numeroAleatorio = Math.floor(Math.random()*5)+1;
//console.log(numeroAleatorio);

/*12)Utiliza Math.random para generar un número entero entre 1 y 10 y muestra ese número en la consola.
*/

//let numeroAleatorio = Math.floor(Math.random()*10)+1;
//console.log(numeroAleatorio);

/*13)Utiliza Math.random para generar un número entero entre 1 y 1000 y muestra ese número en la consola.
*/
//let numeroAleatorio = Math.floor(Math.random()*100)+1;
//console.log(numeroAleatorio);


/*/////////////////////////////SEGUNDA PARTE DEL CURSO JERCICIOS(CREANDO FUNCIONES) //////////////////////////
*/

/*
Crear una función que muestre "¡Hola, mundo!" en la consola.
*/








 













 